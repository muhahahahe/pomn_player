const MODULE_NAME = "pomn_player";
export { MODULE_NAME, };
