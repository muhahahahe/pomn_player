export const MODULE_NAME = "pomn_player";
